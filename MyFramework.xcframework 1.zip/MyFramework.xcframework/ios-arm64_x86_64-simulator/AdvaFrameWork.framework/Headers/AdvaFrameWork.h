//
//  AdvaFrameWork.h
//  AdvaFrameWork
//
//  Created by Eslam on 17/09/2023.
//

#import <Foundation/Foundation.h>

//! Project version number for AdvaFrameWork.
FOUNDATION_EXPORT double AdvaFrameWorkVersionNumber;

//! Project version string for AdvaFrameWork.
FOUNDATION_EXPORT const unsigned char AdvaFrameWorkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AdvaFrameWork/PublicHeader.h>


